function R = multiplication(X1,X2)
R=X1;
if (size(X1,1)==size(X2,1))
    for i=1:size(X1,1)
        for j=1:size(X2,2)
            R(i,j)=0;
            for k=1:size(X2,1)
                R(i,j)=R(i,j)+X1(i,k)*X2(k,j);
            end
        end
    end
end
if (size(X1,1)~=size(X2,2))  
   R='Failed:Inner matrix dimensions must agree';
end