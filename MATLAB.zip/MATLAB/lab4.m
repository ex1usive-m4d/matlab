n=6;
% for i=1:n
%     for j=1:n
%         A(i,j)=i/j-j/i+1;
%     end
% end
A=[0.1429 -3.1500 Inf ;
NaN 8.0000 2.2500 ;
7.0000 4.5000 9.0000;]
A
toZeroEnvy(A)