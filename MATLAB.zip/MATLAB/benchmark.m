clc
A=exp(1:10000);
tic;fft(A);toc
tic;A=randi(1000,1000);toc
tic; k=factor(10000); toc
tic; isprime(A); toc
