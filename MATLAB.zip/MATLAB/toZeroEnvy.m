function A = toZeroEnvy(A)
 A(~isfinite(A) | A<0  | isfinite(A)&&isprime(A) | (A-fix(A))>0 | rem(A,2)==0)=0;
