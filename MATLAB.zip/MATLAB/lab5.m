%  r
% m x n 
%      r   1   
% 
m=4;
n=3;
r=2;
A=randi(m,n)
B=A;
A=zero(1,n)
B(r,:)=ones(1,n);
for i=r:m
    B(i+1,:)=A(i,:);
end
B
