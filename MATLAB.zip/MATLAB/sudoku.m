n=3;
for i=0:8
    for j=0:8
        A(i+1,j+1)=mod(((i*n+fix(i/n)+j)),n*n)+1;
    end
end
A
A=A([3,1,2,5,4,6,9,8,7],:);
A=A'
A=A([3,2,1,6,4,5,7,9,8],:)

