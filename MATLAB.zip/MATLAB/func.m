function R = func(x,y)
if x>0 && y>0
    R=-sqrt(x-y*y);
elseif x<=0 && y<=0
    R=(x-y)*(x-y);
end
    