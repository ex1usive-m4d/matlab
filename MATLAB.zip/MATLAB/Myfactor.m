function f = Myfactor(n)
if n < 4
   f=n; 
   return
else
   f = [];
end

if (isa(n,'uint64') || isa(n,'int64')) && n > flintmax
    p = primes(2.^(nextpow2(n)/2));
else
    p = primes(cast(sqrt(double(n)),class(n)));
end
while n>1,
  d = find(rem(n,p)==0);
  if isempty(d)
    f = [f n];
    break; 
  end
  p = p(d);
  f = [f p];
  n = n/prod(p);
end
f = sort(f);
