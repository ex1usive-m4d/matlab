%lab7_var6
a=4;
b=5;
c=7;
func(a,b)+func(a,c)/func(c,b)